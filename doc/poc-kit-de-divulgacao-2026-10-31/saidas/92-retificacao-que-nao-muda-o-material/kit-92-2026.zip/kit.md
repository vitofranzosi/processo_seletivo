# Kit de divulgação — Edital nº 92/2026

## Para quem divulga

- Houve publicação depois do material anterior (ref. 8cc98a9f), mas ela não muda nada do que o material diz: ele continua valendo.
- Gerado sobre a versão vigente desde 31/10/2026, 11h26 (Retificação nº 1 de 31/10/2026).
- Situação conferida em 06/11/2026, 09h00: Aberta.
- O período publicado termina em 19/11/2026, às 23h59. Depois disso, não republique este material.
- Uma Retificação publicada depois desta geração pode mudar os dados: o GPS avisa na tela do kit quando a ficha mudar.

## Resumo institucional

```text
O Cefor/Ifes publicou o Edital nº 92/2026: Seleção de cadastro de reserva de tutores presenciais e a distância para atuarem nos cursos técnicos e de pós-graduação do Programa Universidade Aberta do Brasil (UAB) ofertados pelo Cefor/Ifes (DEMONSTRAÇÃO). Inscrições de 05/11/2026 a 19/11/2026, até as 23h59 (horário de Brasília). 18 opções de oferta. Condições, documentos exigidos e cronograma completo na página oficial: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/
```

## Legenda para rede social

```text
Edital nº 92/2026 — Cefor/Ifes
Seleção de cadastro de reserva de tutores presenciais e a distância para atuarem nos cursos técnicos e de pós-graduação do Programa Universidade Aberta do Brasil (UAB) ofertados pelo Cefor/Ifes (DEMONSTRAÇÃO)

Inscrições de 05/11/2026 a 19/11/2026, até as 23h59 (horário de Brasília).

18 opções de oferta.
• Tutor a distância do Curso Técnico em Administração na modalidade a distância, vinculado à Rede e-Tec Brasil e ao Programa Universidade Aberta do Brasil — Cefor — atuação remota: 6 vagas e cadastro reserva
• Tutor a distância da Pós-graduação em Informática na Educação — Cefor — atuação remota: 4 vagas e cadastro reserva
• Tutor presencial — Polo UAB de Afonso Cláudio — endereço fictício de demonstração, s/n, Centro: cadastro reserva
• Tutor presencial — Polo UAB de Alegre — endereço fictício de demonstração, s/n, Centro: cadastro reserva
• Tutor presencial — Polo UAB de Aracruz — endereço fictício de demonstração, s/n, Centro: cadastro reserva
• e mais 13 opções na página oficial

Condições, documentos exigidos e cronograma completo na página oficial. Acesse gps.exemplo.ifes.edu.br/selecoes e busque por 92/2026.

As informações repetem o Edital nº 92/2026, conforme a versão vigente desde 31/10/2026, 11h26. Em caso de divergência, vale o Edital.
```

## Chamada curta para o site

```text
Edital nº 92/2026 — Seleção de cadastro de reserva de tutores presenciais e a distância para atuarem nos cursos técnicos e de pós-graduação do Programa Universidade Aberta do Brasil (UAB) ofertados pelo Cefor/Ifes (DEMONSTRAÇÃO): inscrições de 05/11/2026 a 19/11/2026.
```

## Texto para mensagens

```text
O Cefor/Ifes publicou o Edital nº 92/2026: Seleção de cadastro de reserva de tutores presenciais e a distância para atuarem nos cursos técnicos e de pós-graduação do Programa Universidade Aberta do Brasil (UAB) ofertados pelo Cefor/Ifes (DEMONSTRAÇÃO). Inscrições de 05/11/2026 a 19/11/2026, até as 23h59 (horário de Brasília). 18 opções de oferta. Condições, documentos exigidos e cronograma completo na página oficial: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/
```

## Link oficial

```text
https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/
```

## Link de cada opção

```text
Tutor a distância do Curso Técnico em Administração na modalidade a distância, vinculado à Rede e-Tec Brasil e ao Programa Universidade Aberta do Brasil — Cefor — atuação remota: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-cca4b6e8-e16d-54e9-a744-a7156d0bf4a1
Tutor a distância da Pós-graduação em Informática na Educação — Cefor — atuação remota: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-bb146bec-a097-59c4-838d-b9bc6f3ebdf2
Tutor presencial — Polo UAB de Afonso Cláudio — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-7b116b0f-26dc-5734-ba31-d45775b5692f
Tutor presencial — Polo UAB de Alegre — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-d362b570-a475-5416-8c0b-0d7fda3f2b61
Tutor presencial — Polo UAB de Aracruz — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-25762cf9-a738-5ced-931c-9ab233933ef5
Tutor presencial — Polo UAB de Baixo Guandu — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-4caf28b3-f928-5147-b08f-b14227ae25ef
Tutor presencial — Polo UAB de Bom Jesus do Norte — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-b5d72636-ebcb-554e-8644-706f690a68da
Tutor presencial — Polo UAB de Cachoeiro de Itapemirim — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-c1596fc9-2a57-5a10-b8da-ab1e6a975027
Tutor presencial — Polo UAB de Domingos Martins — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-6b96d77a-036f-5829-998d-8ba455acc886
Tutor presencial — Polo UAB de Ecoporanga — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-0846acf6-589e-58e8-86b5-c916870b70fb
Tutor presencial — Polo UAB de Itapemirim — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-cedd3ad8-00fd-5b73-9a19-a3fe82718f2d
Tutor presencial — Polo UAB de Iúna — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-e3073890-7d9b-5795-917b-07e721b4d88d
Tutor presencial — Polo UAB de Linhares — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-cf29fa14-695c-5dca-9a7a-e03ed68e1081
Tutor presencial — Polo UAB de Mantenópolis — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-f4deef79-78ee-52f4-9a98-87e54d8b6c9d
Tutor presencial — Polo UAB de Montanha — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-55bf59a3-1e10-581c-b1e9-5a383d2a0e5b
Tutor presencial — Polo UAB de Nova Venécia — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-8c23c3b8-8f79-5a8d-88cf-edfa1f13e02e
Tutor presencial — Polo UAB de Pinheiros — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-c454df76-5bd3-5866-a5d2-40efba7a8b30
Tutor presencial — Polo UAB de Santa Leopoldina — endereço fictício de demonstração, s/n, Centro: https://gps.exemplo.ifes.edu.br/selecoes/e7ff498e-dd43-41d6-a935-91de7ed8532c/#vaga-cacd65c9-758e-5136-aff8-461753f5b350
```

## Ressalva

```text
As informações repetem o Edital nº 92/2026, conforme a versão vigente desde 31/10/2026, 11h26. Em caso de divergência, vale o Edital.
```
