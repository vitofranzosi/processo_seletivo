# Kit de divulgação — Edital nº 01/2026

## Para quem divulga

- Material anterior (ref. 2e66bcb2) desatualizado. Mudou: término das inscrições (22/11/2026 → 02/12/2026)
- Gerado sobre a versão vigente desde 17/11/2026, 09h43 (Retificação nº 2 de 31/10/2026).
- Situação conferida em 17/11/2026, 10h43: Aberta.
- O período publicado termina em 02/12/2026, às 09h43. Depois disso, não republique este material.
- Uma Retificação publicada depois desta geração pode mudar os dados: o GPS avisa na tela do kit quando a ficha mudar.

## Resumo institucional

```text
O Cefor/Ifes publicou o Edital nº 01/2026: Professor Substituto e Técnico-Administrativo. Inscrições de 02/11/2026 a 02/12/2026, até as 09h43 (horário de Brasília). Prazo prorrogado por Retificação: o término passou de 22/11/2026 para 02/12/2026. 2 opções de oferta. Condições, documentos exigidos e cronograma completo na página oficial: https://gps.exemplo.ifes.edu.br/selecoes/7529c824-8aea-44b3-9c57-f5ebe4cc337c/
```

## Legenda para rede social

```text
Edital nº 01/2026 — Cefor/Ifes
Professor Substituto e Técnico-Administrativo

Inscrições de 02/11/2026 a 02/12/2026, até as 09h43 (horário de Brasília).
Prazo prorrogado por Retificação: o término passou de 22/11/2026 para 02/12/2026.

2 opções de oferta.
• Professor de Informática — Campus Serra: 3 vagas e cadastro reserva
• Técnico de Laboratório — Campus Vitória: cadastro reserva

Condições, documentos exigidos e cronograma completo na página oficial. Acesse gps.exemplo.ifes.edu.br/selecoes e busque por 01/2026.

As informações repetem o Edital nº 01/2026, conforme a versão vigente desde 17/11/2026, 09h43. Em caso de divergência, vale o Edital.
```

## Chamada curta para o site

```text
Edital nº 01/2026 — Professor Substituto e Técnico-Administrativo: inscrições de 02/11/2026 a 02/12/2026.
```

## Texto para mensagens

```text
O Cefor/Ifes publicou o Edital nº 01/2026: Professor Substituto e Técnico-Administrativo. Inscrições de 02/11/2026 a 02/12/2026, até as 09h43 (horário de Brasília). Prazo prorrogado por Retificação: o término passou de 22/11/2026 para 02/12/2026. 2 opções de oferta. Condições, documentos exigidos e cronograma completo na página oficial: https://gps.exemplo.ifes.edu.br/selecoes/7529c824-8aea-44b3-9c57-f5ebe4cc337c/
```

## Link oficial

```text
https://gps.exemplo.ifes.edu.br/selecoes/7529c824-8aea-44b3-9c57-f5ebe4cc337c/
```

## Link de cada opção

```text
Professor de Informática — Campus Serra: https://gps.exemplo.ifes.edu.br/selecoes/7529c824-8aea-44b3-9c57-f5ebe4cc337c/#vaga-00000000-0000-0000-0001-0000000000b1
Técnico de Laboratório — Campus Vitória: https://gps.exemplo.ifes.edu.br/selecoes/7529c824-8aea-44b3-9c57-f5ebe4cc337c/#vaga-00000000-0000-0000-0001-0000000000b2
```

## Ressalva

```text
As informações repetem o Edital nº 01/2026, conforme a versão vigente desde 17/11/2026, 09h43. Em caso de divergência, vale o Edital.
```
